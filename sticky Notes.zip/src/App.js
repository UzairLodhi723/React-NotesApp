import { useState , useEffect } from "react"
import { nanoid } from 'nanoid';
import NotesList from "./Components/NotesList";
import Search from "./Components/Search";
import Header from "./Components/Header"
const App = () =>{
  
  // Adding nanoid 
  const [notes,setNotes]=useState([
    {
    id: nanoid(),
    text:"This is my first note!",
    date:"02/06/2022"
  },
  {
    id: nanoid(),
    text:"This is my second note!",
    date:"02/06/2022"
  },
  {
    id: nanoid(),
    text:"This is my third note!",
    date:"02/06/2022"
  }
]);
// Hook For Search Bar

const [searchText, setSearchText] = useState('');

// hook for Dark Mode

const [darkMode, setDarkMode] = useState(false);

useEffect(() =>{
  const savedNotes =JSON.parse(localStorage.getItem('react-notes-app-date')
  );

  if(savedNotes){
    setNotes(savedNotes);
  }
}, [] );


// in useEffect we use global key for map object
// and convert it into string 

useEffect( () => {
  localStorage.setItem(
    'react-notes-app-date',
    JSON.stringify(notes)
  );
} , [notes]);

// to add date text in note

const addNote = (text) => {
  const date = new Date();
  const newNote ={
    id: nanoid(),
    text: text,
    date: date.toLocaleDateString()
  };
  const newNotes = [...notes, newNote];
  setNotes(newNotes);
};

// Delete Note function

const deleteNote = (id) =>{
  const newNotes = notes.filter((notes) => notes.id !==id);
  setNotes(newNotes);
}

return(
  // in This Div we use template if the dark mode is clicked trun the dark mode on
  <div className={`${darkMode && 'dark-mode'}`}>
      <div className="container">
    <Header 
    handleToggleDarkMode={setDarkMode} 

    />
    
    <Search 
    handleSearchNote={setSearchText} />
    
    <NotesList 
      notes={notes.filter((notes)=>
      notes.text.toLocaleLowerCase().includes(searchText)
      )} 
      handleAddNote={addNote}
      handleDeleteNote ={deleteNote}
      />
    </div>

  </div>
  )
}
export default App;